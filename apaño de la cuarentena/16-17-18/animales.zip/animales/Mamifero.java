package herencia.animales;

public class Mamifero extends Animales {
	private String familia;

	public String getFamilia() {
		return familia;
	}

	public void setFamilia(String familia) {
		this.familia = familia;
	}
}

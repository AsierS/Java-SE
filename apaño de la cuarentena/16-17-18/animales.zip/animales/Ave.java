package herencia.animales;

public class Ave extends Animales{
	private int numAlas;
	private String color;
	public int getNumAlas() {
		return numAlas;
	}
	public void setNumAlas(int numAlas) {
		this.numAlas = numAlas;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
}
